/**
 * Providing methods to read a csv-file as a trace, and then using
 * extended LTL properties to query the trace.
 */
package eu.iv4xr.ux.pxtesting.ltl.offline;